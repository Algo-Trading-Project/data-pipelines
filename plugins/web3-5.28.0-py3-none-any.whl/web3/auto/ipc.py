from web3 import (
    IPCProvider,
    Web3,
)

w3 = Web3(IPCProvider())
