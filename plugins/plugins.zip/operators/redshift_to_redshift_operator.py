from airflow.models import BaseOperator


class RedshiftToRedshiftOperator(BaseOperator):

    def __init__(self, dest_table, query):
        self.dest_table = dest_table
        self.query = query
