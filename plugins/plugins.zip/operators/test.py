from web3_alchemy_to_s3_operator import Web3AlchemyToS3Operator

Web3AlchemyToS3Operator(
            task_id = 'get_historical_eth_data',
            batch_size = '',
            node_endpoint = '',
            bucket_name = 'project-poseidon-data',
            is_historical_run = True,
            start_block_variable_name = 'start_block_{}'.format(1),
            end_block_variable_name = 'end_block_{}'.format(2)
        ).get_start_and_end_block()