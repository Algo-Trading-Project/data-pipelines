start = 1
end = 10

for i in range(end, start - 1, -1):
    print(i)