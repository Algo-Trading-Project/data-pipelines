import requests as r
import pandas as pd
import dateutil.parser as parser


a = '2022-06-02T00:00:00+00:00'

print(parser.parse(a).isoformat().split('+')[0])