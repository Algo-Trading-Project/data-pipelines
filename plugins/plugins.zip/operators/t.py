import requests as r

k = 'https://rest.coinapi.io/v1/ohlcv/YOBIT_SPOT_C20_ETH/history?period_id=1DAY&time_start=2022-06-02T00:00:00+00:00&limit=100000'
headers = {'X-CoinAPI-Key':'3D83399F-4F0F-4E07-A933-AE3F18E1AF65'}

response = r.get(
    url = k,
    headers = headers,
)

response_json = response.json()


print(response_json)