import pandas as pd
import json

with open('coinapi_data/coinapi_pair_metadata.json', 'r') as f:
    s = f.read()
    f.close()

s = ('[' + s.strip() + ']').replace('}', '},').replace('},]', '}]')
js = json.loads(s)
p = pd.DataFrame(js)

print(p[(p['exchange_id'] == 'KRAKEN') ])